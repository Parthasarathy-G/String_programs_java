import java.util.*;

public class Main
{
  
public static void main (String args[])
  {
    
Scanner ps = new Scanner (System.in);
    
String s1 = ps.nextLine ();
    
String[]words = s1.split (":");
  
for (String w:words)
      {
	
System.out.println (w);
      
}
  
}
}

