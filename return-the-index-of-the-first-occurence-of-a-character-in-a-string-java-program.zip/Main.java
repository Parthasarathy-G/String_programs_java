 import java.util.*;
 public class Main{
     public static void main(String arsg[]){
         Scanner ps = new Scanner(System.in);
         String s = ps.next();
         int sum =0;
         char c = ps.next().charAt(0);
         for(int i = 0;i<s.length();i++){
             char ch = s.charAt(i);
             if(c==ch){
                 System.out.print(i);
                 sum++;
                return;
             }}
             if(sum==0)
             System.out.println("-1");
             
         
     }
 }

