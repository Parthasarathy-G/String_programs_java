import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner ps = new Scanner(System.in);
        String s = ps.next();
        ps.nextLine();
        String s1 = ps.nextLine().replaceAll(" ","").replaceAll(",",""),s4[] = s.split("");
        if(s1.length()>s.length()){
            System.out.print("NO");
            return;
        }
        for(int i = 0;i<s4.length;i++){
            s1 = s1.replaceFirst(s4[i],"");
        }
        System.out.print(s1.length() == 0 ? "YES" : "NO");
    }
}