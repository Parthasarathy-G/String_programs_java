import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt();ps.nextLine();
        
        for(int i = 0;i<n;i++){
            String s = ps.nextLine(),s1[] = s.split(" ");
            if(s1[0].equals(s1[1])){
                System.out.println("Strings are equal");
            }
            else{
                System.out.println("Strings are not equal");
            }
        }
    }
}