import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner n = new Scanner(System.in);
        String a = n.nextLine();
        int n1 = n.nextInt(),temp=0,j=0;
        String str = n.next(),s="";
             String a1[] = new String[100];
        String arr[] = a.split(" "); 

        for(int i = 0 ;i<arr.length;i++,j++)
{
    a1[i]="";         
    if(str.equals(arr[i])){
    ++temp;
            if(n1==temp){
              arr[i]="";
    }}
    a1[i]= a1[i]+arr[i];
    System.out.print(a1[i].replaceAll("\\s", "")+" ");
}
    }
}





