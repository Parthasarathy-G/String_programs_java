import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps=new Scanner(System.in);
        int n=ps.nextInt();
        ps.nextLine();
        for(int i=1;i<=n;i++){
            String s=ps.nextLine();
            String s1=s.toLowerCase();

            for(int j=0;j<s1.length();j++){
                char ch=s1.charAt(j);
                if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
                ch=Character.toUpperCase(ch);
                System.out.print(ch);
            }
        }
    }
}