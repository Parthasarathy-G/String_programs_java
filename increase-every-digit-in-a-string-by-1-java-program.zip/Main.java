/*Write a program to increase every digit by 1 in a given string. If it is not a digit then the character should not be modified*/
import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner na = new Scanner(System.in);
        String s = na.next(),s1[] = s.split("");
        for(int i = 0;i<s1.length;i++){
            int k = Integer.parseInt(s1[i]);
            if(k!=9){
                k=k+1;
            }
            System.out.print(k);
        }
    }
}
