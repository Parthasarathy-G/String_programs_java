import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner hp=new Scanner(System.in);
        int n=hp.nextInt();
        hp.nextLine();
        for(int i=1;i<=n;i++){
            String s=hp.nextLine();
            String ans="";
            int c=0;
            for(int j=0;j<s.length();j++){
                char ch=s.charAt(j);
                if(ch>='0'&&ch<='9')
                ans+=""+ch;
                else
                ans+=" ";
            }
            String a[]=ans.split(" ");
            for(int j=0;j<a.length;j++){
                String s1=a[j];
                if(s1.equals(""))
                c++;
                else
                System.out.print(s1+" ");
            }
            System.out.println();
        }
    }
}