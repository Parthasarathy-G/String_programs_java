import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        String s = ps.next();
        String h="";
        int j = s.length();
        for(int  i = j-1;i>0;i--){
            char ch = s.charAt(i);
            h = h+ch;
        }
        if(s.equals(h)){
            System.out.println("p");
        }
        else{
            System.out.println("np");
        }
    }
}
