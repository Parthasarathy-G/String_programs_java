import java.util.*;
public class Main{
    public static void main(String[] psl){
        Scanner ps = new Scanner(System.in);
        String[] s = ps.nextLine().split(" ");
        LinkedHashSet<String> l = new LinkedHashSet();
        for(int i = 0;i<s.length;i++){
            l.add(s[i]);
        }
        int k = 0;
        for(String i : l){
        int count = 0;
        for(int j = k;j<s.length;j++){
            if(i.equals(s[j])){
                count++;
            }
        }
        System.out.println(i+" "+count);
            k++;
        }
        
    }
}