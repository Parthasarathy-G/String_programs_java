import java.util.*;
public class Main{
   public static void main(String args[]){
       Scanner sc = new Scanner(System.in);
       String s = sc.next(),ch[] = s.split("");
       LinkedHashSet<String> t1 = new LinkedHashSet<>();
       for(int i = 0;i<s.length();i++){
           t1.add(ch[i]);
       }
       String[] a = t1.toArray(new String[t1.size()]);
       for(int i = 0;i<a.length;i++){
        System.out.print(a[i]);
       }
       
   }
}



