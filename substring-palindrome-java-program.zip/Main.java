/*Given a string s which consists of lowercase or uppercase letters, return the length of the longest palindrome that can be built with those letters.
Letters are case sensitive, for example, "Aa" is not considered a palindrome here.*/
import java.util.*;
public class Main {
	static String findLongestPalindrome(String str) {
		int count[] = new int[256];
		for (int i = 0; i < str.length(); i++) {
			count[str.charAt(i)]++;
		}

		String beg = "", mid = "", end = "";
		for (char ch = 'a'; ch <= 'z'; ch++) {
			if (count[ch] % 2 == 1) {
				mid = String.valueOf(ch);
				count[ch--]--;
			} 
			else {
				for (int i = 0; i < count[ch] / 2; i++) {
					beg += ch;
				}
			}
		}
		end = beg;
		end = reverse(end);
      String k=beg+mid+end;
      int h=k.length();
      String o=Integer.toString(h);
		return o;
	}

	static String reverse(String str) {
		String ans = "";
		char[] try1 = str.toCharArray();

		for (int i = try1.length - 1; i >= 0; i--) {
			ans += try1[i];
		}
		return ans;
	}
	public static void main(String[] args) {
	    Scanner ps =new Scanner(System.in);
		String str = ps.next();
		System.out.println(findLongestPalindrome(str));
	}
}