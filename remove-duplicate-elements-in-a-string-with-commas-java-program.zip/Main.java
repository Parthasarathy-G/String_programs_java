//Given an integer array nums sorted in non-decreasing order, remove the duplicates in-place such that each unique element appears only once. The relative order of the elements should be kept the same.//
import java.util.*;
public class Main{
   public static void main(String args[]){
       Scanner ps = new Scanner(System.in);
       String s = ps.next();
String ch[] = s.split(",");
TreeSet<String> t1 = new TreeSet<String>();
        for(String s3 : ch){
            t1.add(s3);
        }
        
        System.out.println(t1.toString().trim().replace("[","").replace("]","").replace("=","").replace(" ",""));
   }
}



