import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner ps = new Scanner(System.in);
		String s = ps.next();
		String s1 = ps.next();
		int i = Integer.valueOf(s);
		int j = Integer.valueOf(s1);
		System.out.println(i*j);
	}
}

