import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner n = new Scanner(System.in);
        String a = n.nextLine();
        int n1 = n.nextInt(),temp=0,j=0;
        String str = n.next(),s="";
        String arr[] = a.split(" "); 
     
        for(int i = 0 ;i<arr.length;i++,j++)

{          if(str.equals(arr[i])){
    ++temp;
            if(n1==temp){
        arr[i] = "";
    }}
    s+=arr[i];
    System.out.print(arr[i]+" ");
}
    }
}
