/*Given two strings s and t, determine if they are isomorphic.
Two strings s and t are isomorphic if the characters in s can be replaced to get t.
All occurrences of a character must be replaced with another character while preserving the order of characters. 
No two characters may map to the same character, but a character may map to itself*/
import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        String s1 = ps.next(),s2[]=s1.split("");
        String s3 = ps.next(),s4[] = s3.split("");
        String s5="",s6="";
        for(int i =0;i<s2.length;i++){
        for(int j = i;j<s2.length;j++){
            if(s2[i].equals(s2[j])){
                s5+="1";
            }
            else{
                s5+="0";
            }
        }}
         for(int i =0;i<s2.length;i++){
         for(int j = i;j<s2.length;j++){
            if(s4[i].equals(s4[j])){
                s6+="1";
            }
            else{
                s6+="0";
            }}
        }
        if(s5.equals(s6)){
        System.out.print("true");
        }
        else{
        System.out.print("false");
        }
    }
}