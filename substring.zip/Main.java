import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine(),substring = sc.nextLine();
        if(!str.contains(substring)){
            System.out.print("-1");
        }
        else{
            while (str.contains(substring)) {
                str = str.replace(substring, "");
            }
            if (str.length() > 0) {
                System.out.println(str.length());
            }
            else{
                System.out.print("0");
            }
        }
    }
}
