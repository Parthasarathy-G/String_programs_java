/*Get 2 strings as input. Assume that both the strings have equal length.
If the corresponding characters in both strings are not equal, add both the ASCII values
Find the total of the ASCII values.
Print the total
If the answer is a
1 digit number print "ONE"
2 digit number print "TWO"
3 digit number print "THREE"
else print "NONE"

For example:

Input
Hello
Haido

Trilo
TRIIo

Result
619
THREE

196
THREE*/
import java.util.*;
public class main{
    public static void main(String args[]){
        Scanner ps=new Scanner(System.in);
        String s1=ps.next();
        String s2=ps.next();
        String y="";
        int a,b,n;
        int sum=0;
        if(s1.length()==s2.length())
        {
            for(int i=0;i<s1.length();i++){
                if(s1.charAt(i)!=s2.charAt(i)){
                a=s1.charAt(i);
                b=s2.charAt(i);
                n=a+b;
                sum+=n;}
            }
        }
        System.out.println(sum);
        String z=Integer.toString(sum);
        if(z.length()==1)
        System.out.print("ONE");
        else if(z.length()==2)
        System.out.print("TWO");
        else if(z.length()==3)
        System.out.print("THREE");
        else
        System.out.print("NONE");
    }
}