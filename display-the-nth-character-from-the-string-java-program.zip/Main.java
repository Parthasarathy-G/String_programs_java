import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        String s = ps.next();
        int n = ps.nextInt();
        int j = n-1;
        for(int i = 0;i<s.length();i++){
                    char ch = s.charAt(i);
            if(i==j){
                System.out.print(ch);
                break;
            }
        }
    }
}
