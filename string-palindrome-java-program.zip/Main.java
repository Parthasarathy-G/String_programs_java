import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        String s = ps.next(),sum="";
        String h = s.toLowerCase();
      for(int i=s.length()-1;i>=0;i--)
    sum+= h.charAt(i);
String g = sum.toLowerCase();
      if(h.equals(g))
       System.out.print("Palindrome");
       else
       System.out.print("Not a palindrome");
    }
}


