import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        int a=sc.nextInt();
        String str[]=s.split(" ");
        String s1=sc.next();
        int f=0,i=0;
        for(i=0;i<str.length;i++)
        {
            if(str[i].equals(s1))
                a--;
            if(a!=0){
                System.out.print(str[i]+" ");
            }
            if(a==0)
                break;
        }
        i++;
        for(;i<str.length;i++)
        {
            System.out.print(str[i]+" ");
            
            
        }
        
    }
}
